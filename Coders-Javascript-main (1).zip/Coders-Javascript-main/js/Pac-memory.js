import { startGame } from "./components/varsAndElements.js";
startGame()